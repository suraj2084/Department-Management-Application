package com.example.android.admincollegeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MCACourse extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mcacourse);
    }
}